<?php

/* @var $this yii\web\View */

$this->title = 'User Auth';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Home Page!</h1>
    </div>
</div>
