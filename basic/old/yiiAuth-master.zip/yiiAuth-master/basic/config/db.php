<?php

return [
    'class'    => 'yii\db\Connection',
    'dsn'      => 'mysql:host=basic;dbname=yii_auth',
    'username' => 'root',
    'password' => '',
    'charset'  => 'utf8',
];
