<?php

return [
    'adminEmail'  => 'lamer_10@mail.ru',
    'senderEmail' => 'lamer_10@mail.ru',
    'senderName'  => 'lamer_10@mail.ru',
];
